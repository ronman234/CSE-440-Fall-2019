﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public KeyCode moveLeft = KeyCode.A;
    public KeyCode moveRight = KeyCode.D;
    public KeyCode jump = KeyCode.Space;

    public float speedMultiplier = 5.0f;
    public float jumpPower = 5.0f;
    public Transform groundDetection;
    public LayerMask ground;
    private Rigidbody2D rb;
    private bool isGrounded;
    private bool secondJumpused;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        isGrounded = Physics2D.OverlapCircle(groundDetection.position, 0.1f, ground);
        Debug.Log("isGrounded" + isGrounded);
        if (isGrounded)
        {
            Debug.Log("secondJumpused" + secondJumpused);
            if (Input.GetKeyDown(jump))
            {
                rb.AddForce(Vector2.up * jumpPower, ForceMode2D.Impulse);
                Debug.Log("I am jumping");
            }
            secondJumpused = true;
        }
        if (!isGrounded & secondJumpused)
        {
            Debug.Log("secondJumpused" + secondJumpused);
            if (Input.GetKeyDown(jump))
            {
                rb.AddForce(Vector2.up * jumpPower, ForceMode2D.Impulse);
                Debug.Log("I am jumping");
                secondJumpused = false;
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        Vector2 newMovement;

        if (Input.GetKey(moveLeft))
        {
            newMovement = new Vector2(rb.position.x - (Time.deltaTime * speedMultiplier), rb.position.y);
            rb.position = newMovement;
        }
        if (Input.GetKey(moveRight))
        {
            newMovement = new Vector2(rb.position.x + (Time.deltaTime * speedMultiplier), rb.position.y);
            rb.position = newMovement;
        }
    }
}
