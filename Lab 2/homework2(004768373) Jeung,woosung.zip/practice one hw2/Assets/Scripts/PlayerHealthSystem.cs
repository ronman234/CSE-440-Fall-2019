﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerHealthSystem : MonoBehaviour
{
    public int Health = 40;
    public int damage = 5;
    public int NukeDamage = 6;

    void Start()
    {
        print(Health);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Enemy")
        {
            Health -= damage;
            print("Player damage now from enemy! -5 from enemy your health:" + Health);
        }

        if (collision.gameObject.tag == "Nuke")
        {
            Health -= NukeDamage;
            print("Player damage now from Nuke! -6 from nuke your health:" + Health);
        }


    }
    void Die()
    {
        Health = 0;
        Debug.Log("Player died.");
    }
}

