﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public KeyCode moveLeft = KeyCode.A;
    public KeyCode moveRight = KeyCode.D;
    public KeyCode jump = KeyCode.Space;

    public int TotalJump=2;
    public int CurrentJump;
    public float timer;

    public float speedMultiplier = 5.0f;
    public float jumpPower = 5.0f;
    public Transform groundDetection;
    public LayerMask ground;

    bool canJump;


    private Rigidbody2D rb;
    private bool isGrounded;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        isGrounded = Physics2D.OverlapCircle(groundDetection.position, 0.1f, ground);

        Debug.Log("isGrounded: " + isGrounded);

        if (isGrounded)
        {
            if (Input.GetKeyDown(jump))
            {
                rb.AddForce(Vector2.up * jumpPower, ForceMode2D.Impulse);
                Debug.Log("I am jumping.");
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        Vector2 newMovement;

        if (Input.GetKey(moveLeft))
        {
            newMovement = new Vector2(rb.position.x - (Time.deltaTime * speedMultiplier), rb.position.y);
            rb.position = newMovement;
        }
        if (Input.GetKey(moveRight))
        {
            newMovement = new Vector2(rb.position.x + (Time.deltaTime * speedMultiplier), rb.position.y);
            rb.position = newMovement;
        }
        if(Input.GetKeyDown(KeyCode.Space)&& !isGrounded && CurrentJump > 1)
        {
            CurrentJump--;
            timer = 0;
            canJump = true;
            GetComponent<Rigidbody2D>().velocity = new Vector2(GetComponent<Rigidbody2D>().velocity.x, 3);

        }

        if (isGrounded)
            CurrentJump = TotalJump;
    }
}
